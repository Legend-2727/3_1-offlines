public interface iCrews {
    public String getName();
    public void repair();
    public void work();
    public void login();
    public void logout();
}
