package Shakes;

public enum ShakeType {
    CHOCOLATE,COFFEE, STRAWBERRY,VANILLA,ZERO;
}
