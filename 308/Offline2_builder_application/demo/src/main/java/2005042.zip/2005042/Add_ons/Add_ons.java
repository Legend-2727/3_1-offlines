package Add_ons;

public abstract class Add_ons {
    protected Integer incrementPrice;

    public abstract Integer getIncrementPrice();
    public abstract String getType();
}
